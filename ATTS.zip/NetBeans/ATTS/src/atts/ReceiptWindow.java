/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atts;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
/**
 *
 * @author Engilo Grave
 */
public class ReceiptWindow {
    	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReceiptWindow window = new ReceiptWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ReceiptWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 650, 370);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PLANE TICKET RECIEPT");
		lblNewLabel.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 11, 169, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(Color.BLACK);
		panel.setBounds(28, 23, 180, 2);
		frame.getContentPane().add(panel);
		
		JLabel lblBook = new JLabel("Booking Date:");
		lblBook.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 12));
		lblBook.setBounds(20, 32, 169, 14);
		frame.getContentPane().add(lblBook);
		
		JLabel lblGuestName = new JLabel("Guest Name:");
		lblGuestName.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 12));
		lblGuestName.setBounds(20, 73, 169, 14);
		frame.getContentPane().add(lblGuestName);
		
		JLabel lblFlight = new JLabel("Flight Delight");
		lblFlight.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 14));
		lblFlight.setBounds(10, 111, 169, 14);
		frame.getContentPane().add(lblFlight);
		
		JLabel lblRoute = new JLabel("Route:");
		lblRoute.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 12));
		lblRoute.setBounds(20, 126, 169, 14);
		frame.getContentPane().add(lblRoute);
		
		JLabel lblFrom = new JLabel("From:");
		lblFrom.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblFrom.setBounds(10, 151, 50, 14);
		frame.getContentPane().add(lblFrom);
		
		JLabel lblAirline = new JLabel("Airline:");
		lblAirline.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblAirline.setBounds(129, 151, 50, 14);
		frame.getContentPane().add(lblAirline);
		
		JLabel lblDepatureDate = new JLabel("Depature Date:");
		lblDepatureDate.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblDepatureDate.setBounds(260, 151, 111, 14);
		frame.getContentPane().add(lblDepatureDate);
		
		JLabel lblArrivalDate = new JLabel("Arrival Date:");
		lblArrivalDate.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblArrivalDate.setBounds(460, 151, 111, 14);
		frame.getContentPane().add(lblArrivalDate);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(10, 224, 610, 2);
		frame.getContentPane().add(panel_1);
		
		JLabel lblTo = new JLabel("To:");
		lblTo.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblTo.setBounds(10, 237, 50, 14);
		frame.getContentPane().add(lblTo);
		
		JLabel lblFlightNumber = new JLabel("Flight Number:");
		lblFlightNumber.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblFlightNumber.setBounds(129, 237, 90, 14);
		frame.getContentPane().add(lblFlightNumber);
		
		JLabel lblDepatureTerminal = new JLabel("Depature Terminal:");
		lblDepatureTerminal.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblDepatureTerminal.setBounds(294, 237, 111, 14);
		frame.getContentPane().add(lblDepatureTerminal);
		
		JLabel lblArrivalTerminal = new JLabel("Arrival Terminal:");
		lblArrivalTerminal.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblArrivalTerminal.setBounds(474, 237, 111, 14);
		frame.getContentPane().add(lblArrivalTerminal);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		btnNewButton.setBounds(531, 297, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(28, 48, 499, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setBounds(28, 86, 499, 14);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("");
		lblNewLabel_1_2.setBounds(10, 176, 99, 14);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("");
		lblNewLabel_1_2_1.setBounds(119, 176, 99, 14);
		frame.getContentPane().add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("");
		lblNewLabel_1_2_1_1.setBounds(260, 176, 174, 37);
		frame.getContentPane().add(lblNewLabel_1_2_1_1);
		
		JLabel lblNewLabel_1_2_1_1_1 = new JLabel("");
		lblNewLabel_1_2_1_1_1.setBounds(460, 176, 160, 37);
		frame.getContentPane().add(lblNewLabel_1_2_1_1_1);
		
		JLabel lblNewLabel_1_2_2 = new JLabel("");
		lblNewLabel_1_2_2.setBounds(10, 262, 99, 14);
		frame.getContentPane().add(lblNewLabel_1_2_2);
		
		JLabel lblNewLabel_1_2_2_1 = new JLabel("");
		lblNewLabel_1_2_2_1.setBounds(129, 262, 99, 14);
		frame.getContentPane().add(lblNewLabel_1_2_2_1);
		
		JLabel lblNewLabel_1_2_2_1_1 = new JLabel("");
		lblNewLabel_1_2_2_1_1.setBounds(294, 262, 99, 14);
		frame.getContentPane().add(lblNewLabel_1_2_2_1_1);
		
		JLabel lblNewLabel_1_2_2_1_1_1 = new JLabel("");
		lblNewLabel_1_2_2_1_1_1.setBounds(474, 262, 99, 14);
		frame.getContentPane().add(lblNewLabel_1_2_2_1_1_1);
	}
}
