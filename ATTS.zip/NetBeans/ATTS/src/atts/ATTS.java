/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atts;

/**
 *
 * @author Engilo Grave
 */
public class ATTS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginWindow login = new LoginWindow();
    }
    
}
