/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atts;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.SwingConstants;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 *
 * @author Engilo Grave
 */
public class MainWindow {
    private JFrame frmAirline;
	private JTable table;

	private Border emptyBorder = BorderFactory.createEmptyBorder();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow window = new MainWindow();
					window.frmAirline.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAirline = new JFrame();
		frmAirline.getContentPane().setBackground(new Color(0, 128, 192));
		frmAirline.setTitle("Airline Transportation Ticketing System");
		frmAirline.setBounds(100, 100, 650, 500);
		frmAirline.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAirline.setResizable(false);
		frmAirline.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Engilo Grave\\Desktop\\ATTS\\Logo.png"));
		frmAirline.getContentPane().setLayout(null);
		
		table = new JTable();
		table.setBounds(10, 163, 614, 241);
		frmAirline.getContentPane().add(table);
		
		JLabel lblNewLabel = new JLabel("Available Flights:");
		lblNewLabel.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 23));
		lblNewLabel.setBounds(10, 105, 185, 31);
		frmAirline.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(30, 147, 550, 5);
		frmAirline.getContentPane().add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_1.setBounds(424, 11, 200, 30);
		frmAirline.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 14));
		lblNewLabel_1.setBounds(0, 0, 200, 30);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblStatus = new JLabel("Status:");
		lblStatus.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 16));
		lblStatus.setBounds(388, 52, 60, 31);
		frmAirline.getContentPane().add(lblStatus);
		
		JLabel lblStatusHere = new JLabel("status here");
		lblStatusHere.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 12));
		lblStatusHere.setBounds(398, 76, 83, 17);
		frmAirline.getContentPane().add(lblStatusHere);
		
		JButton btnNewButton = new JButton("Book Here");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBorder(null);
		btnNewButton.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
		btnNewButton.setBackground(new Color(0, 128, 192));
		btnNewButton.setBounds(481, 415, 143, 35);
		frmAirline.getContentPane().add(btnNewButton);
		
		JButton btnCheckReceipt = new JButton("Check Receipt");
		btnCheckReceipt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnCheckReceipt.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
		btnCheckReceipt.setBorder(null);
		btnCheckReceipt.setBackground(new Color(0, 128, 192));
		btnCheckReceipt.setBounds(481, 104, 143, 35);
		frmAirline.getContentPane().add(btnCheckReceipt);
	}
}
    