/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atts;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
/**
 *
 * @author Engilo Grave
 */
public class Booking_Flight {
    private JFrame frmAirlineTicketingTransportation;
	private JTextField txtOrigin;
	private JTextField txtDestination;
	private JTextField txtDepart;
	private JTextField txtReturn;
	private JLabel lblNewLabel;
	private JLabel lblRoundTrip;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Booking_Flight window = new Booking_Flight();
					window.frmAirlineTicketingTransportation.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Booking_Flight() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAirlineTicketingTransportation = new JFrame();
		frmAirlineTicketingTransportation.setTitle("Airline Ticketing Transportation System");
		frmAirlineTicketingTransportation.setBounds(100, 100, 690, 250);
		frmAirlineTicketingTransportation.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Engilo Grave\\Desktop\\ATTS\\Logo.png"));
		frmAirlineTicketingTransportation.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAirlineTicketingTransportation.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(94, 70, 500, 70);
		frmAirlineTicketingTransportation.getContentPane().add(panel);
		panel.setLayout(null);
		
		txtOrigin = new JTextField();
		txtOrigin.setText("Origin");
		txtOrigin.setBounds(10, 24, 99, 20);
		panel.add(txtOrigin);
		txtOrigin.setColumns(10);
		
		JButton btnNewButton = new JButton("Book Flight");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(401, 23, 89, 23);
		panel.add(btnNewButton);
		
		txtDestination = new JTextField();
		txtDestination.setText("Destination");
		txtDestination.setBounds(109, 24, 86, 20);
		panel.add(txtDestination);
		txtDestination.setColumns(10);
		
		txtDepart = new JTextField();
		txtDepart.setText("Depart");
		txtDepart.setBounds(219, 24, 86, 20);
		panel.add(txtDepart);
		txtDepart.setColumns(10);
		
		txtReturn = new JTextField();
		txtReturn.setText("Return");
		txtReturn.setBounds(305, 24, 86, 20);
		panel.add(txtReturn);
		txtReturn.setColumns(10);
		
		lblNewLabel = new JLabel("Flight");
		lblNewLabel.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 11, 99, 14);
		panel.add(lblNewLabel);
		
		lblRoundTrip = new JLabel("Round Trip");
		lblRoundTrip.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 14));
		lblRoundTrip.setBounds(219, 11, 99, 14);
		panel.add(lblRoundTrip);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_1.setBounds(464, 11, 200, 30);
		frmAirlineTicketingTransportation.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 14));
		lblNewLabel_1.setBounds(0, 0, 200, 30);
		panel_1.add(lblNewLabel_1);
	}
}
